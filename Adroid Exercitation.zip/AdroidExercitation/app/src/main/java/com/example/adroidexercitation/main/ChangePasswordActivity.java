package com.example.adroidexercitation.main;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.adroidexercitation.R;

public class ChangePasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_password);
    }
}